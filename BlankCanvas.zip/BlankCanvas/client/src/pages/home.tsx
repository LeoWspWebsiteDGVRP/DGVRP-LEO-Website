import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Shield, FileText, Users, Settings } from "lucide-react";

export default function Home() {
  return (
    <div className="law-bg min-h-screen flex items-center justify-center">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <header className="text-center mb-12">
          <div className="flex justify-center items-center mb-4">
            <Shield className="h-16 w-16 text-blue-400 mr-4" />
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">
                Law Enforcement Management System
              </h1>
              <p className="text-slate-300 text-lg">
                Professional Citation and Violation Management Platform
              </p>
            </div>
          </div>
          <Badge variant="outline" className="text-blue-400 border-blue-400">
            Version 1.0 - Active
          </Badge>
        </header>

        {/* Main Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">

          {/* Citation Management */}
          <Card className="law-card hover:bg-slate-800 transition-colors">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <FileText className="h-6 w-6 mr-2 text-blue-400" />
                Citation Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300 mb-4">
                Create, manage, and process traffic citations and violations with comprehensive penal code database.
              </p>
              <div className="space-y-2 mb-4">
                <div className="text-sm text-slate-400">Features:</div>
                <ul className="text-sm text-slate-300 space-y-1">
                  <li>• 120+ Penal Codes</li>
                  <li>• Automatic Fine Calculation</li>
                  <li>• Jail Time Tracking</li>
                  <li>• Professional Forms</li>
                </ul>
              </div>
              <Link href="/citation">
                <Button className="law-accent-btn text-white font-semibold w-full">
                  Create Citation
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Records Management */}
          <Card className="law-card hover:bg-slate-800 transition-colors">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Users className="h-6 w-6 mr-2 text-green-400" />
                Records Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300 mb-4">
                View and manage citation records, search violations, and generate reports.
              </p>
              <div className="space-y-2 mb-4">
                <div className="text-sm text-slate-400">Features:</div>
                <ul className="text-sm text-slate-300 space-y-1">
                  <li>• Search Citations</li>
                  <li>• Filter by Officer</li>
                  <li>• Export Reports</li>
                  <li>• Statistics Dashboard</li>
                </ul>
              </div>
              <Button className="bg-green-600 hover:bg-green-700 text-white font-semibold w-full">
                View Records
              </Button>
            </CardContent>
          </Card>

          {/* System Administration */}
          <Card className="law-card hover:bg-slate-800 transition-colors">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Settings className="h-6 w-6 mr-2 text-orange-400" />
                Administration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300 mb-4">
                System settings, user management, and administrative functions.
              </p>
              <div className="space-y-2 mb-4">
                <div className="text-sm text-slate-400">Features:</div>
                <ul className="text-sm text-slate-300 space-y-1">
                  <li>• User Management</li>
                  <li>• System Settings</li>
                  <li>• Audit Logs</li>
                  <li>• Backup & Security</li>
                </ul>
              </div>
              <Button className="bg-orange-600 hover:bg-orange-700 text-white font-semibold w-full">
                Admin Panel
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Links */}
        <div className="mt-8 flex justify-center space-x-4">
          <Link href="/">
            <Button variant="outline" className="text-white border-slate-600 hover:bg-slate-700">
              Back to Selection
            </Button>
          </Link>
          <Link href="/citation">
            <Button variant="outline" className="text-white border-slate-600 hover:bg-slate-700">
              Go to Citation Form
            </Button>
          </Link>
          <Link href="/arrest">
            <Button variant="outline" className="text-white border-slate-600 hover:bg-slate-700">
              Go to Arrest Form
            </Button>
          </Link>
        </div>

        {/* Quick Stats */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
          <Card className="law-card text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-blue-400">120+</div>
              <div className="text-sm text-slate-300">Penal Codes</div>
            </CardContent>
          </Card>
          <Card className="law-card text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-400">24/7</div>
              <div className="text-sm text-slate-300">System Uptime</div>
            </CardContent>
          </Card>
          <Card className="law-card text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-orange-400">Secure</div>
              <div className="text-sm text-slate-300">Data Protection</div>
            </CardContent>
          </Card>
          <Card className="law-card text-center">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-purple-400">Pro</div>
              <div className="text-sm text-slate-300">Law Enforcement</div>
            </CardContent>
          </Card>
        </div>

        {/* Footer */}
        <footer className="text-center mt-12 pt-8 border-t border-slate-700">
          <p className="text-slate-400 text-sm">
            Law Enforcement Management System - Professional Citation Platform
          </p>
          <p className="text-slate-500 text-xs mt-2">
            Authorized Personnel Only - All Activities Logged
          </p>
        </footer>
      </div>
    </div>
  );
}